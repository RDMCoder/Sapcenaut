import discord
from discord.ext import commands

class Moderation(commands.Cog):

  def __init__(self, client):
    self.client = client

  @commands.command()
  @commands.has_permissions(manage_messages = True)
  async def clear(self, ctx,amount=1):
    await ctx.channel.purge(limit = amount)
    await ctx.send("~Transmissions cleared~")



  @commands.command()
  @commands.has_permissions(ban_members = True)
  async def ban(self, ctx, member : discord.Member, *, reason= "No reason provided"):
    try:
      await member.ban(reason=reason)
      await ctx.send(member.name + " has been banned from this guild., Reason:"+reason)
    except:
      await ctx.send("The member has their DM's closed.")



  @commands.command()
  @commands.has_permissions(kick_members = True)
  async def kick(self, ctx, member : discord.Member, *, reason= "No reason provided"):
    try:
      await member.kick(reason=reason)
      await ctx.send(member.name + " has been kicked from this guild., Reason:"+reason)
    except:
      await ctx.send("The member has their DM's closed.")
      



  @commands.command()
  @commands.has_permissions(ban_members=True)
  async def unban(self, ctx,*,member):
    banned_users = await ctx.guild.bans()
    member_name, member_disc = member.split('#')

    for banned_entry in banned_users:
      user = banned_entry.user
    if(user.name, user.discriminator)==(member_name,member_disc):

      await ctx.guild.unban(user)
      await ctx.send(member_name +" has been unbanned!")
    return

    await ctx.send(member+" was not found.")


  @commands.command()
  @commands.has_permissions(kick_members=True)
  async def whois(self, ctx, member : discord.Member):
    embed = discord.Embed(title = member.name , description = member.mention , color =     discord.Colour.green ())
    embed.add_field(name = "ID", value = member.id , inline = True )
    embed.set_thumbnail(url = member.avatar_url)
    embed.set_footer(icon_url = ctx.author.avatar_url, text = f"Requested by {ctx.author.name}")
    await ctx.send(embed=embed)
    await ctx.message.delete()
    



  @commands.command()
  @commands.has_permissions(kick_members=True)
  async def mute(self, ctx,member : discord.Member):
    muted_role = ctx.guild.get_role(817501953760034866)

    await member.add_roles(muted_role)

    await ctx.send(member.mention + " has been muted.")



  @commands.command()
  @commands.has_permissions(kick_members=True)
  async def unmute(self, ctx,member : discord.Member):
    muted_role = ctx.guild.get_role(817501953760034866)

    await member.remove_roles(muted_role)

    await ctx.send(member.mention + " has been unmuted.")




def setup(client):
  client.add_cog(Moderation(client))
