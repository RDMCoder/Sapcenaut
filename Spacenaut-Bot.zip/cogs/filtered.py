import discord
from discord.ext import commands

class Filter(commands.Cog):

  def __init__(self, client):
    self.client = client



filtered_words = ["cat","dog"]
 


@commands.Cog.listener()
async def on_message(self, msg):
  if word in msg.content:
    await msg.delete()

    await client.process_commands(msg)



  




def setup(client):
  client.add_cog(Filter(client))