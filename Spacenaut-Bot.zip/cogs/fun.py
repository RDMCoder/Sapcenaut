import discord
from discord.ext import commands

class Fun(commands.Cog):

  def __init__(self, client):
    self.client = client
  
  @commands.command()
  async def hello(self, ctx):
    await ctx.send("Hi, my astronaut friend!")



  @commands.command()
  async def door(self, ctx):
    await ctx.send("https://gph.is/2LIp6Aw")



  @commands.command()
  async def rocket(self, ctx):
    await ctx.send("https://gph.is/g/Z7nK8Wd")



  @commands.command()
  async def rickroll(self, ctx, member : discord.Member):
    await ctx.send(f"{member.mention}, You just got rick rolled!")
    await ctx.send("http://gph.is/2efdN3V")
    await ctx.message.delete()



def setup(client):
  client.add_cog(Fun(client))